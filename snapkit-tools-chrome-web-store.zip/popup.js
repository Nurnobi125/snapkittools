(() => {
  const themeToggle = document.querySelector('#theme-toggle');
  let theme = localStorage.getItem('snapkit-popup-theme');
  if (theme !== 'dark' && theme !== 'light') {
    theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  const setTheme = (value) => {
    theme = value;
    document.documentElement.dataset.theme = theme;
    themeToggle.setAttribute('aria-pressed', String(theme === 'dark'));
    const next = theme === 'dark' ? 'light' : 'dark';
    themeToggle.innerHTML = `<span aria-hidden="true">${next === 'dark' ? '☾' : '☀'}</span>${next === 'dark' ? 'Dark' : 'Light'}`;
    themeToggle.setAttribute('aria-label', `Switch to ${next} theme`);
    localStorage.setItem('snapkit-popup-theme', theme);
  };
  setTheme(theme);
  themeToggle.addEventListener('click', () => setTheme(theme === 'dark' ? 'light' : 'dark'));

  const base = 'https://snapkittools.online/';
  const tools = [
    { id:'image-to-pdf', name:'Image to PDF', category:'PDF', desc:'Create a PDF from images', icon:'▧', url:'tools/image-to-pdf/' },
    { id:'merge-pdf', name:'Merge PDF', category:'PDF', desc:'Combine PDF files', icon:'▤', url:'tools/merge-pdf/' },
    { id:'pdf-to-image', name:'PDF to Image', category:'PDF', desc:'Save a PDF page as PNG or JPG', icon:'▧', url:'tools/pdf-to-image/' },
    { id:'extract-pdf-pages', name:'Extract PDF Pages', category:'PDF', desc:'Save selected pages to a new PDF', icon:'⇥', url:'tools/extract-pdf-pages/' },
    { id:'rotate-pdf', name:'Rotate PDF', category:'PDF', desc:'Rotate pages in a PDF', icon:'⟳', url:'tools/rotate-pdf/' },
    { id:'pdf-page-count', name:'PDF Page Counter', category:'PDF', desc:'Check the number of PDF pages', icon:'ⓘ', url:'tools/pdf-page-count/' },
    { id:'jpg-to-png', name:'JPG to PNG', category:'Image', desc:'Convert JPG images to PNG', icon:'◉', url:'tools/jpg-to-png/' },
    { id:'png-to-jpg', name:'PNG to JPG', category:'Image', desc:'Convert PNG images to JPG', icon:'◉', url:'tools/png-to-jpg/' },
    { id:'webp-to-jpg', name:'WebP to JPG', category:'Image', desc:'Convert WebP images to JPG', icon:'◉', url:'tools/webp-to-jpg/' },
    { id:'webp-to-png', name:'WebP to PNG', category:'Image', desc:'Convert WebP images to PNG', icon:'◉', url:'tools/webp-to-png/' },
    { id:'png-to-webp', name:'PNG to WebP', category:'Image', desc:'Convert PNG images to WebP', icon:'◉', url:'tools/png-to-webp/' },
    { id:'jpg-to-webp', name:'JPG to WebP', category:'Image', desc:'Convert JPG images to WebP', icon:'◉', url:'tools/jpg-to-webp/' },
    { id:'avif-to-jpg', name:'AVIF to JPG', category:'Image', desc:'Convert AVIF images to JPG', icon:'◉', url:'tools/avif-to-jpg/' },
    { id:'svg-to-png', name:'SVG to PNG', category:'Image', desc:'Convert SVG graphics to PNG', icon:'◇', url:'tools/svg-to-png/' },
    { id:'svg-to-jpg', name:'SVG to JPG', category:'Image', desc:'Convert SVG graphics to JPG', icon:'◇', url:'tools/svg-to-jpg/' },
    { id:'svg-to-pdf', name:'SVG to PDF', category:'Image', desc:'Place SVG artwork in a PDF', icon:'◇', url:'tools/svg-to-pdf/' },
    { id:'word-counter', name:'Word Counter', category:'Text', desc:'Count words and characters', icon:'Aa', url:'tools/word-counter/' },
    { id:'character-counter', name:'Character Counter', category:'Text', desc:'Count characters with or without spaces', icon:'Ab', url:'tools/character-counter/' },
    { id:'lorem-ipsum-generator', name:'Lorem Ipsum Generator', category:'Text', desc:'Generate placeholder text', icon:'¶', url:'tools/lorem-ipsum-generator/' },
    { id:'text-compare', name:'Text Compare', category:'Text', desc:'Compare two pieces of text', icon:'⇄', url:'tools/text-compare/' },
    { id:'json-formatter', name:'JSON Formatter', category:'Developer', desc:'Format and validate JSON', icon:'{ }', url:'tools/json-formatter/' },
    { id:'json-minifier', name:'JSON Minifier', category:'Developer', desc:'Minify valid JSON', icon:'{ }', url:'tools/json-minifier/' },
    { id:'json-to-csv', name:'JSON to CSV', category:'Developer', desc:'Convert JSON data to CSV', icon:'⇢', url:'tools/json-to-csv/' },
    { id:'csv-to-json', name:'CSV to JSON', category:'Developer', desc:'Convert CSV data to JSON', icon:'⇠', url:'tools/csv-to-json/' },
    { id:'url-encoder', name:'URL Encoder', category:'Developer', desc:'Encode text for URLs', icon:'↗', url:'tools/url-encoder/' },
    { id:'url-parser', name:'URL Parser', category:'Developer', desc:'Inspect URL parts and parameters', icon:'⌕', url:'tools/url-parser/' },
    { id:'regex-tester', name:'Regex Tester', category:'Developer', desc:'Test regular expressions', icon:'.*', url:'tools/regex-tester/' },
    { id:'base64-encoder', name:'Base64 Encoder', category:'Developer', desc:'Encode or decode Base64 text', icon:'64', url:'tools/base64-encoder/' },
    { id:'sha256-generator', name:'SHA-256 Generator', category:'Developer', desc:'Create a SHA-256 text hash', icon:'#', url:'tools/sha256-generator/' },
    { id:'password-generator', name:'Password Generator', category:'Developer', desc:'Generate a password in your browser', icon:'⚿', url:'tools/password-generator/' },
    { id:'percentage-calculator', name:'Percentage Calculator', category:'Calculator', desc:'Calculate percentages', icon:'%', url:'tools/percentage-calculator/' },
    { id:'discount-calculator', name:'Discount Calculator', category:'Calculator', desc:'Calculate sale price and savings', icon:'−', url:'tools/discount-calculator/' },
    { id:'tip-calculator', name:'Tip Calculator', category:'Calculator', desc:'Calculate a tip and bill total', icon:'+', url:'tools/tip-calculator/' },
    { id:'age-calculator', name:'Age Calculator', category:'Calculator', desc:'Calculate age from date of birth', icon:'◷', url:'tools/age-calculator/' },
    { id:'date-difference-calculator', name:'Date Difference', category:'Calculator', desc:'Count days between dates', icon:'▦', url:'tools/date-difference-calculator/' },
    { id:'color-contrast-checker', name:'Color Contrast Checker', category:'Design', desc:'Check WCAG color contrast', icon:'◐', url:'tools/color-contrast-checker/' },
    { id:'all-tools', name:'All 500+ Everyday Tools', category:'More', desc:'Browse and search the full toolbox', icon:'✳', url:'everyday-tools.html' }
  ];

  const list = document.querySelector('#tools');
  const search = document.querySelector('#search');
  const status = document.querySelector('#status');
  const empty = document.querySelector('#empty');
  const categoryNav = document.querySelector('#categories');
  const categories = ['All', ...new Set(tools.map((tool) => tool.category))];
  let selectedCategory = 'All';
  let selectedView = 'all';
  const readSet = (key) => {
    try { return new Set(JSON.parse(localStorage.getItem(key) || '[]')); }
    catch { return new Set(); }
  };
  const favorites = readSet('snapkit-favorites');
  const recent = readSet('snapkit-recent');
  const cards = new Map();

  function makeCard(tool) {
    const item = document.createElement('article');
    item.className = 'tool';
    item.dataset.category = tool.category;
    item.dataset.search = `${tool.name} ${tool.desc} ${tool.category}`.toLocaleLowerCase();
    const link = document.createElement('a');
    link.className = 'tool-link';
    link.href = base + tool.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    const icon = document.createElement('span');
    icon.className = 'tool-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = tool.icon;
    const copy = document.createElement('span');
    copy.className = 'tool-copy';
    const title = document.createElement('span');
    title.className = 'tool-name';
    title.textContent = tool.name;
    const desc = document.createElement('span');
    desc.className = 'tool-desc';
    desc.textContent = tool.desc;
    copy.append(title, desc);
    link.append(icon, copy);

    const favorite = document.createElement('button');
    favorite.type = 'button';
    favorite.className = 'favorite';
    favorite.title = 'Add to favorites';
    favorite.setAttribute('aria-label', `Add ${tool.name} to favorites`);
    favorite.addEventListener('click', () => {
      if (favorites.has(tool.id)) favorites.delete(tool.id);
      else favorites.add(tool.id);
      localStorage.setItem('snapkit-favorites', JSON.stringify([...favorites]));
      updateFavoriteUI();
      filterTools();
    });
    link.addEventListener('click', () => {
      recent.delete(tool.id);
      recent.add(tool.id);
      localStorage.setItem('snapkit-recent', JSON.stringify([...recent].slice(-8)));
    });
    item.append(link, favorite);
    list.append(item);
    cards.set(tool.id, { item, favorite, tool });
  }

  function updateFavoriteUI() {
    document.querySelector('#favorite-count').textContent = favorites.size;
    for (const [id, card] of cards) {
      const saved = favorites.has(id);
      card.favorite.textContent = saved ? '★' : '☆';
      card.favorite.classList.toggle('saved', saved);
      card.favorite.title = saved ? 'Remove from favorites' : 'Add to favorites';
      card.favorite.setAttribute('aria-label', `${saved ? 'Remove' : 'Add'} ${card.tool.name} ${saved ? 'from' : 'to'} favorites`);
    }
  }

  function filterTools() {
    const query = search.value.trim().toLocaleLowerCase();
    const recentOrder = [...recent].reverse();
    let count = 0;
    for (const [id, card] of cards) {
      let match = !query || card.item.dataset.search.includes(query);
      if (selectedCategory !== 'All') match &&= card.tool.category === selectedCategory;
      if (selectedView === 'favorites') match &&= favorites.has(id);
      if (selectedView === 'recent') match &&= recent.has(id);
      card.item.style.order = selectedView === 'recent' ? String(Math.max(0, recentOrder.indexOf(id))) : '0';
      card.item.hidden = !match;
      if (match) count++;
    }
    empty.hidden = count > 0;
    status.textContent = query ? `${count} tool${count === 1 ? '' : 's'} found` : `${count} ${selectedCategory === 'All' ? '' : selectedCategory + ' '}tool${count === 1 ? '' : 's'}`;
  }

  for (const tool of tools) makeCard(tool);
  for (const category of categories) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `category${category === 'All' ? ' active' : ''}`;
    button.textContent = category;
    button.addEventListener('click', () => {
      selectedCategory = category;
      categoryNav.querySelector('.active')?.classList.remove('active');
      button.classList.add('active');
      filterTools();
    });
    categoryNav.append(button);
  }
  document.querySelectorAll('.view').forEach((button) => button.addEventListener('click', () => {
    selectedView = button.dataset.view;
    document.querySelector('.view.active')?.classList.remove('active');
    button.classList.add('active');
    filterTools();
  }));
  search.addEventListener('input', filterTools);
  document.addEventListener('keydown', (event) => {
    if (event.key === '/' && document.activeElement !== search) {
      event.preventDefault();
      search.focus();
    }
  });
  updateFavoriteUI();
  filterTools();
})();
